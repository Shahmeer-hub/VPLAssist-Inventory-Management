﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using VPLAssistPlus.Models;

namespace VPLAssistPlus
{
    public partial class MainWindow : Window
    {
        private List<Product> products = new List<Product>();
        private string filePath = "products.json";

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            await Task.Run(() =>
            {
                Thread.Sleep(1000); // simulate loading
                LoadData();
            });

            RefreshGrid();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product p = new Product(
                    int.Parse(txtID.Text),
                    txtName.Text,
                    (cmbCategory.SelectedItem as ComboBoxItem)?.Content.ToString(),
                    decimal.Parse(txtPrice.Text),
                    int.Parse(txtQuantity.Text)
                );

                products.Add(p);
                SaveData();
                RefreshGrid();
            }
            catch
            {
                MessageBox.Show("Invalid input. Please check all fields.");
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product p)
            {
                p.Name = txtName.Text;
                p.Category = (cmbCategory.SelectedItem as ComboBoxItem)?.Content.ToString();
                p.Price = decimal.Parse(txtPrice.Text);
                p.Quantity = int.Parse(txtQuantity.Text);

                SaveData();
                RefreshGrid();
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product p)
            {
                products.Remove(p);
                SaveData();
                RefreshGrid();
            }
        }

        private void dgProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgProducts.SelectedItem is Product p)
            {
                txtID.Text = p.ProductID.ToString();
                txtName.Text = p.Name;
                txtPrice.Text = p.Price.ToString();
                txtQuantity.Text = p.Quantity.ToString();
            }
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            string keyword = txtSearch.Text.ToLower();
            dgProducts.ItemsSource = products
                .Where(p => p.Name.ToLower().Contains(keyword))
                .ToList();
        }

        private void ShowAll_Click(object sender, RoutedEventArgs e)
        {
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            dgProducts.ItemsSource = null;
            dgProducts.ItemsSource = products;

            lblCount.Content = $"Total Products: {products.Count}";
            lblValue.Content = $"Total Value: {products.Sum(p => p.Price * p.Quantity):C}";
        }

        private void SaveData()
        {
            File.WriteAllText(filePath, JsonConvert.SerializeObject(products, Formatting.Indented));
        }

        private void LoadData()
        {
            if (File.Exists(filePath))
            {
                products = JsonConvert.DeserializeObject<List<Product>>(File.ReadAllText(filePath))
                           ?? new List<Product>();
            }
        }
    }
}
